package sharingRegions;

import communication.Message;
import communication.Stub;
import Enum.*;
import java.util.*;

import java.io.*;

public class Repository {

	//winnerHoreses
	public Repository(){
		
	}

	/**
	*	Function to write in the log files the update values.
	*
	*/
	public void toLog() throws IOException{
		sendMessage(new Message("toLog"));
	}


	/**
	*	Function to remove all the horses that were running.
	*
	*/
	public void clearhorsesRunning() throws IOException{
		sendMessage(new Message("clearhorsesRunning"));
	}

	/**
	*	Function to return the number of races that left.
	*
	* 	@return int the number of races missing.
	*/
	public int getNumberOfRacesMissing() throws IOException{
		return (int) sendMessage(new Message("getNumberOfRacesMissing")).getReturn();
	}

	/**
	*	Function to update the number of races that were made.
	*	
	*/
	public void raceDone() throws IOException{
		sendMessage(new Message("raceDone"));
	}
	

	/**
	*	Function to update the broker state
	*
	* 	@param brokerstate state.
	* 	
	*/
	public void setbrokerstate(BrokerState brokerstate) throws IOException{
		sendMessage(new Message("setbrokerstate", new Object[] {brokerstate}));
	}

	public void turnOffServer() throws IOException{
		sendMessage(new Message(".EndServer"));
	}

	public Message sendMessage(Message message) throws IOException{

		String hostName; // nome da máquina onde está o servidor
		Properties prop = new Properties();
		String propFileName = "config.properties";
 	
		prop.load(new FileInputStream("resources/"+propFileName));
		
		int portNumb = Integer.parseInt(prop.getProperty("portRepository"));
		//int portNumb = 9949; // número do port

		hostName = "localhost";

		/* troca de mensagens com o servidor */

		Stub stub; // stub de comunicação

		stub = new Stub(hostName, portNumb);
		return stub.exchange(message);	
	}

	
}
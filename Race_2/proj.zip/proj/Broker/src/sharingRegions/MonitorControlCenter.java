package sharingRegions;

import Interfaces.IBroker_Control;
import communication.Message;
import communication.Stub;
import java.io.*;
import java.util.*;


//import com.sun.corba.se.pept.broker.Broker;

public class MonitorControlCenter implements IBroker_Control{

	public MonitorControlCenter() {
	
	}
	
	
	/**
	*	Function for broker report the horses that won the last race.
	*
	*	@param horseAWinners Array with the horses that won the last race.
	*/
	@Override
	public void reportResults(int[] horseAWinners) throws IOException {
		try{
			sendMessage(new Message("reportResults",new Object[]{horseAWinners}));
		}catch(IOException e ){
			e.printStackTrace();
		}
	}

	/**
	*	Function for broker wait for spectators.
	*
	*	
	*/
	@Override
	public void entertainTheGuests() throws IOException{
		try{
			sendMessage(new Message("entertainTheGuests"));
		}catch(IOException e ){
			e.printStackTrace();
		}
	}
	
	@Override
	public void turnOffServer() throws IOException{
		try{
			sendMessage(new Message(".EndServer"));
		}catch(IOException e ){
			e.printStackTrace();
		}
	}
	
	public Message sendMessage(Message message) throws IOException{

		String hostName; // nome da maquina onde esta o servidor
		Properties prop = new Properties();
		String propFileName = "config.properties";
 	
		prop.load(new FileInputStream("resources/"+propFileName));
		
		int portNumb = Integer.parseInt(prop.getProperty("portControlCenter"));
		//int portNumb = 9959; // número do port

		hostName = "localhost";

		/* troca de mensagens com o servidor */

		Stub stub; // stub de comunicacao

		stub = new Stub(hostName, portNumb);
		return stub.exchange(message);	
	}
}

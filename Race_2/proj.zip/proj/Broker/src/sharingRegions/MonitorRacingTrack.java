package sharingRegions;

import Interfaces.IBroker_Track;
import communication.Message;
import communication.Stub;
import java.util.*;

import java.io.*;


public class MonitorRacingTrack implements IBroker_Track{
	

	public MonitorRacingTrack() {
		
	}
	/**
	*	Waits until all horses are in starting line to start the race.
	*
	*/
	@Override
	public void startTheRace() throws IOException{
		try{	
			sendMessage(new Message("startTheRace"));
		}catch(IOException e ){
			e.printStackTrace();
		}
	}
	
	@Override
	public void turnOffServer() throws IOException{
		try{
			sendMessage(new Message(".EndServer"));
		}catch(IOException e ){
			e.printStackTrace();
		}
	}
	
	/**
	*	Report the results to spectators returning an array with rankings
	*
	*	@return int[] horseAWinners 
	*/
	@Override
	public int[] reportResults() throws IOException{
		return (int[]) sendMessage(new Message("reportResults")).getReturn();
        
	}
	public Message sendMessage(Message message) throws IOException{

		String hostName; // nome da maquina onde esta o servidor
		Properties prop = new Properties();
		String propFileName = "config.properties";
 	
		prop.load(new FileInputStream("resources/"+propFileName));
		
		int portNumb = Integer.parseInt(prop.getProperty("portRacingTrack"));
		//int portNumb = 9979; // número do port

		hostName = "localhost";

		/* troca de mensagens com o servidor */

		Stub stub; // stub de comunicacao

		stub = new Stub(hostName, portNumb);
		return stub.exchange(message);	
	}
	

	
}

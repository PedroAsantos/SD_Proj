package sharingRegions;

import Interfaces.IBroker_Paddock;
import communication.Message;
import communication.Stub;
import java.io.*;
import java.util.*;

public class MonitorPaddock implements IBroker_Paddock{


	public MonitorPaddock() {
		
	}
	
	@Override
	public void turnOffServer() throws IOException{
		try{
			sendMessage(new Message(".EndServer"));
		}catch(IOException e ){
			e.printStackTrace();
		}
	}
	
	public Message sendMessage(Message message) throws IOException{

		String hostName; // nome da maquina onde esta o servidor
		Properties prop = new Properties();
		String propFileName = "config.properties";
 	
		prop.load(new FileInputStream("resources/"+propFileName));
		
		int portNumb = Integer.parseInt(prop.getProperty("portPaddock"));
		//int portNumb = 9969; // numero do port

		hostName = "localhost";

		/* troca de mensagens com o servidor */

		Stub stub; // stub de comunicacao

		stub = new Stub(hostName, portNumb);
		return stub.exchange(message);	
	}
}

package sharingRegions;


import Interfaces.IBroker_BettingCenter;
import communication.Message;
import communication.Stub;
import java.io.*;
import java.util.*;


public class MonitorBettingCenter implements IBroker_BettingCenter {



	public MonitorBettingCenter() {
		
	}
	/**
	*	Function to broker accept the bets of spectators.
	*
	*	 
	*/
	@Override
	public void acceptTheBets() throws IOException{
		try{
			sendMessage(new Message("acceptTheBets") );

		}catch(IOException e ){
			e.printStackTrace();
		}
	}

	@Override
	public void honourTheBets() throws IOException{
		try{
			sendMessage(new Message("honourTheBets") );
		}catch(IOException e ){
			e.printStackTrace();
		}
	}
	/**
	*	Function to broker verify if any spectator won the bet. 
	*
	*	@param horseAWinners Array with the horses that won the last race.
	*   @return boolean returns true if at least one spectator won the bet.
	*/
	@Override
	public boolean areThereAnyWinners(int[] horseAWinners) throws IOException{
		return (boolean) sendMessage(new Message("areThereAnyWinners", new Object[] {horseAWinners})).getReturn();
	}
	
	@Override
	public void turnOffServer() throws IOException{
		try{
			sendMessage(new Message(".EndServer"));
		}catch(IOException e ){
			e.printStackTrace();
		}
	}

	public Message sendMessage(Message message) throws IOException{

		String hostName; // nome da maquina onde esta o servidor
		Properties prop = new Properties();
		String propFileName = "config.properties";
 	
		prop.load(new FileInputStream("resources/"+propFileName));
		
		int portNumb = Integer.parseInt(prop.getProperty("portBettingCenter"));
		//int portNumb = 9989; // número do port

		hostName = "localhost";

		/* troca de mensagens com o servidor */

		Stub stub; // stub de comunicacao

		stub = new Stub(hostName, portNumb);
		return stub.exchange(message);	
	}
	

}

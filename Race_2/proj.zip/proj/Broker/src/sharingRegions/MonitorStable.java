package sharingRegions;


import Interfaces.IBroker_Stable;
import communication.Message;
import communication.Stub;
import java.util.*;

import java.io.*;

public class MonitorStable implements IBroker_Stable {

	public MonitorStable() {


	}

	@Override
	public void turnOffServer() throws IOException{
		try{
			sendMessage(new Message(".EndServer"));
		}catch(IOException e ){
			e.printStackTrace();
		}
	}
	/**
	 * When the event are ending the horses are going to the end of event
	 *
	 * 
	 */
	@Override
	public void summonHorsesToEnd() throws IOException{
		try{
			sendMessage(new Message("summonHorsesToEnd"));
		}catch(IOException e ){
			e.printStackTrace();
		}
	}

	/**
	 * All horses go to paddock
	 *
	 * 
	 */
	@Override
	public void summonHorsesToPaddock() throws IOException{
		try{
			sendMessage(new Message("summonHorsesToPaddock"));
		}catch(IOException e ){
			e.printStackTrace();
		}
	}

	public Message sendMessage(Message message) throws IOException{

		String hostName; // nome da maquina onde esta o servidor

		Properties prop = new Properties();
		String propFileName = "config.properties";
 		int portNumb;
 		
			prop.load(new FileInputStream("resources/"+propFileName));
			
			portNumb = Integer.parseInt(prop.getProperty("portStable"));
			//int portNumb = 9999; // numero do port

			hostName = "localhost";
		
		/* troca de mensagens com o servidor */

		Stub stub; // stub de comunicacao

		stub = new Stub(hostName, portNumb);
		return stub.exchange(message);	
	}
	
}

package Interfaces;
import java.io.*;

public interface IBroker_Paddock {
	public void turnOffServer() throws IOException;
}

package Interfaces;
import java.io.*;

public interface IBroker_Stable {
	public void summonHorsesToPaddock() throws IOException;
	public void summonHorsesToEnd() throws IOException;
	public void turnOffServer() throws IOException; 
}

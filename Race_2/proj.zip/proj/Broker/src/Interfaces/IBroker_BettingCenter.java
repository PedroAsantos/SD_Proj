package Interfaces;
import java.io.*;

public interface IBroker_BettingCenter {
	public void acceptTheBets() throws IOException;
	public void honourTheBets() throws IOException;
	public boolean areThereAnyWinners(int[] horseAWinners) throws IOException;
	void turnOffServer() throws IOException;

}

package Interfaces;
import java.io.*;

public interface IBroker_Track {
	public void startTheRace() throws IOException;
	public int[] reportResults() throws IOException;
	void turnOffServer() throws IOException;
}

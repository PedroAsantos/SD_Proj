package Interfaces;
import java.io.*;

public interface IBroker_Control {
	public void reportResults(int[] horseAWinners) throws IOException;
	public void entertainTheGuests() throws IOException;
	void turnOffServer() throws IOException;
}

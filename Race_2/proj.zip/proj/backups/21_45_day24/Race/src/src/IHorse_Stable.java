package src;

public interface IHorse_Stable {
	 public void proceedToStable(int id);

}

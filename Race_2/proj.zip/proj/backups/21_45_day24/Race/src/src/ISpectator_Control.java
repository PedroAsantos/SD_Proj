package src;

public interface ISpectator_Control {
	public void goWatchTheRace(int spectator_id);
	public void relaxABit();
	public boolean haveIwon(int spectator_id);
	public boolean noMoreRaces();
}

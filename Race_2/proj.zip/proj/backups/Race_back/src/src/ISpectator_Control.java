package src;

public interface ISpectator_Control {
	public void goWatchTheRace(int spectator_id);
	public boolean haveIwon();
	public void relaxABit();

}

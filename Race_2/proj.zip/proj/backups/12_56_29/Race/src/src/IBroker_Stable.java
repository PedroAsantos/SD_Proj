package src;

public interface IBroker_Stable {
	public void summonHorsesToPaddock();
}

package src;

import stakeholders.Spectator;

public interface ISpectator_BettingCenter {
	public void placeABet(Spectator spectator);
	public void goCollectTheGains(Spectator spectator);
}

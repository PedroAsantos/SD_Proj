package Interfaces;

public interface IBroker_BettingCenter {
	public void acceptTheBets();
	public void honourTheBets();
	public boolean areThereAnyWinners(int[] horseAWinners);

}

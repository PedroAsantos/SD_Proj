package Interfaces;


public interface IBroker_Track {
	public void startTheRace();
	public int[] reportResults();
}

package Interfaces;

public interface ISpectator_Paddock {
	public int goCheckHorses(int spectator_id);
	public void waitForNextRace(int spectator_id);
}

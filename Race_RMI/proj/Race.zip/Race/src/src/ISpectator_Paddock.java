package src;

public interface ISpectator_Paddock {
	public void goCheckHorses(int spectator_id);
	public void waitForNextRace(int spectator_id);
}

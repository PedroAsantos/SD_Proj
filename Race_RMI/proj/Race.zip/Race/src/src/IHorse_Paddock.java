package src;

import stakeholders.Horse;

public interface IHorse_Paddock {
    public void proceedToPaddock(Horse horse);
}

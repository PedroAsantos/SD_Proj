package src;

import java.util.List;

public interface IBroker_Track {
	public void startTheRace();
	public List<Integer> reportResults();
}

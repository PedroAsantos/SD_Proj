package src;

import java.util.List;

public interface IBroker_Control {
	public void reportResults(List<Integer> result);
	public void entertainTheGuests();
}

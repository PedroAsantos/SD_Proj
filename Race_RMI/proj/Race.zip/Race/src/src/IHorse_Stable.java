package src;

import stakeholders.Horse;

public interface IHorse_Stable {
	 public void proceedToStable(Horse horse);

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

import java.rmi.Remote;

/**
 *
 * @author rute
 */
public interface IMonitor_Paddock extends Remote, IHorse_Paddock,ISpectator_Paddock{
    
}

package Enum;

public enum HorseState {
	AT_THE_STABLE, AT_THE_PADDOCK, AT_THE_START_LINE, RUNNING, AT_THE_FINISH_LINE
}

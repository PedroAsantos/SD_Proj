package Interfaces;

public interface IBroker_Stable {
	public void summonHorsesToPaddock();
	public void summonHorsesToEnd();
}

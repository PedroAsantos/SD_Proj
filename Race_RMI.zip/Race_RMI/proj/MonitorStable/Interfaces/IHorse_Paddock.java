package Interfaces;

public interface IHorse_Paddock {
    public void proceedToPaddock(int horseId,int performance);
}

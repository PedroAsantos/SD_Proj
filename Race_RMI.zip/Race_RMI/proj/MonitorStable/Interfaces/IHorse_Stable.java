package Interfaces;


public interface IHorse_Stable {
	 public boolean proceedToStable(int horseId);

}

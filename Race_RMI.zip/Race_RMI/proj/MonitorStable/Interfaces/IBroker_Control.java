package Interfaces;

public interface IBroker_Control {
	public void reportResults(int[] horseAWinners);
	public void entertainTheGuests();
}
